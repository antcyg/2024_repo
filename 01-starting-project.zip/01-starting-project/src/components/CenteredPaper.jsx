import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';

function CenteredPaper({ text }) {
  return (

      <Paper elevation={20} square={true} sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#222f3e', // Dark background for the Paper
        color: '#ffffff', // White text for readability
        width: '100%',
        height: '100%',
        position: 'absolute',
      }}>
        <Typography variant="h6" component="p" textAlign="center">
          {text}
        </Typography>
      </Paper>
  );
};

export default CenteredPaper;