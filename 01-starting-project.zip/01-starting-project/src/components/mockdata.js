

const mock_data_1 = [
    {
      "chapter_name": "The Tuesday Night Club",
      "chapter_order": 1,
      "episode_id": "ce21b16b-70e5-4020-8766-5ed564a8ce19",
      "episode_order": 9,
    },
    {
      "chapter_name": "The Tuesday Night Club",
      "chapter_order": 1,
      "episode_id": "96c9c9ba-a458-4e38-80a2-f286a6f4f205",
      "episode_order": 10,
    },
    {
      "chapter_name": "The Tuesday Night Club",
      "chapter_order": 1,
      "episode_id": "bd45e933-89f6-403d-85df-44ba6f0b4681",
      "episode_order": 11,
    },
    {
      "chapter_name": "The Tuesday Night Club",
      "chapter_order": 1,
      "episode_id": "3ac113c6-a84b-4c85-9dcc-32a026b96fb5",
      "episode_order": 12,
    },
];


export default mock_data_1;