import React, {useState} from "react";
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import PauseIcon from '@mui/icons-material/Pause';
import TipsAndUpdatesOutlinedIcon from '@mui/icons-material/TipsAndUpdatesOutlined';
import { Box, Fade, Modal, Backdrop } from '@mui/material';
import { Typography } from '@mui/material';
import '@google/model-viewer';


function MainBox({handlePageClick, currentPart, iconState, playPauseState, navIconState}){

return (
<Box
onClick={handlePageClick}
sx={{
  position: 'fixed',
  top: 0,
  left: 0,
  width: '100vw',
  height: '100vh',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  cursor: 'pointer',
  zIndex: -1, // Adjust as needed
  background: 'linear-gradient(to right, #1a2937 0%, #222f3e 20%, #222f3e 80%, #1a2937 100%)',

}}

>
<Typography variant="h4" component="h1" textAlign="center" sx={
  { 
    zIndex: 1,
    width: '70%', // Set the width to 70% of its parent container
    margin: 'auto', // Automatically adjust margins to center the text block
    fontSize: {
      xs: '1.2rem', // smaller devices
      sm: '1.8rem', // slightly larger screens
      md: '2.3rem', // default size for medium and above
    },
  }}>
  {currentPart ? currentPart.value : 'End of Episode'}
</Typography>

<Fade in={iconState.show} timeout={500}>
  <Box
    sx={{
      position: 'fixed',
      top: '50%',
      transform: 'translateY(-50%)',
      ...(iconState.direction === 'left' ? { left: '20px' } : { right: '20px' }),
      zIndex: 2,
    }}
  >
    {iconState.direction === 'left' ? <ArrowBackIosNewIcon fontSize="large" /> : <ArrowForwardIosIcon fontSize="large" />}
  </Box>
</Fade>

<Fade in={playPauseState.show} timeout={500}>
    <Box
      sx={{
        position: 'fixed',
        bottom: '50px', // Position at the bottom center
        left: '50%',
        transform: 'translateX(-50%)',
        zIndex: 2,
      }}
    >
      {playPauseState.isPlaying ? <PauseIcon fontSize="large" /> : <PlayArrowIcon fontSize="large" />}
    </Box>
  </Fade>

<Fade in={navIconState.show} timeout={500}>
  <Box
    sx={{
      position: 'fixed',
      top: '20px', // Adjust as needed for your design
      right: '20px', // Position on the top right corner
      zIndex: 2,
    }}
  >
    <TipsAndUpdatesOutlinedIcon fontSize="large" /> {/* Use the appropriate icon */}
  </Box>
</Fade>

</Box>);
}

export default MainBox;