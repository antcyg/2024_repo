import React, { useEffect } from 'react';

const GlobalClickListener = ({ togglePlayPause, navigateNext }) => {
  useEffect(() => {
    const handleClick = (e) => {
      const { innerWidth: viewportWidth } = window;
      const thirdOfViewport = viewportWidth / 3;
      const clickPosition = e.clientX; // Get horizontal click position

      if (clickPosition >= thirdOfViewport && clickPosition < 2 * thirdOfViewport) {
        togglePlayPause(); // Play or pause the media
      } else if (clickPosition >= 2 * thirdOfViewport) {
        navigateNext(); // Navigate to the next content
      }
    };

    // Add event listener to the whole window
    window.addEventListener('click', handleClick);

    // Cleanup the event listener on component unmount
    return () => {
      window.removeEventListener('click', handleClick);
    };
  }, [togglePlayPause, navigateNext]); // Ensure the effect runs correctly when dependencies change

  return null; // This component does not render anything
};

export default GlobalClickListener;
