import React ,{ useEffect, useRef } from 'react';

function Narration({ url, isPlaying, startTime = -1, endTime = -1 }) {
  const audioRef = useRef(null);
  const prevUrl = useRef(url); // Track the previous URL
  const duration = startTime !== -1 && endTime !== -1 ? endTime - startTime : null;

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      if (endTime !== -1 && audio.currentTime >= endTime / 1000) {
        audio.pause();
        audio.currentTime = 0; // Optionally rewind the audio
      }
    };


    const playNarration = async () => {
      try {
        // If the URL has changed, update the source
        if (audio.src !== url) {
          audio.src = url;
          prevUrl.current = url;
        }

        // Set the start time and play the audio
        audio.currentTime = startTime / 1000; // Convert ms to seconds
        audio.volume = 1.0;
        await audio.play();

        /*
        if (duration !== null) {
          // Schedule stopping the audio after the calculated duration
          setTimeout(() => {
            audio.pause();
            audio.currentTime = 0; // Optionally rewind the audio
          }, duration);
        }*/

      } catch (error) {
        console.error("Error playing the narration:", error);
      }
    };

    if (isPlaying) {
      playNarration();
    } else {
      audio.pause();
    }

    audio.addEventListener('timeupdate', handleTimeUpdate);

    // Cleanup function to pause and rewind the audio when the component unmounts or before next play
    return () => {
      audio.pause();
      audio.currentTime = 0;
      audio.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, [url, isPlaying, startTime, endTime]); // Re-run the effect if either the URL or the start time changes

  return <audio ref={audioRef} preload="auto" hidden />;
}

export default Narration;