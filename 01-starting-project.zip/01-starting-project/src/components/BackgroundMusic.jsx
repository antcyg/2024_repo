// BackgroundMusic.jsx
import React, { useEffect, useRef } from 'react';

function BackgroundMusic({ url, isPlaying, volume=0.15 }) {
  const audioRef = useRef(null);
  const prevUrl = useRef(url); // Track the previous URL

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    
    console.log('audio:', audio);

    const playBGM = async () => {
      try {
        // If the URL has changed, update the source
        if (audio.src !== url) {
          audio.src = url;
          prevUrl.current = url;
        }

        audio.currentTime = 0; 
        audio.volume = volume;
        await audio.play();

      } catch (error) {
        console.error("Error playing the narration:", error);
      }
    };

    console.log('isPlaying:', isPlaying);

    if (isPlaying) {
      playBGM();
    } 

    // Cleanup function to pause and rewind the audio when the component unmounts or before next play
    return () => {
      audio.pause();
      audio.currentTime = 0;
      audio.volume = volume;
    };
  }, [url, isPlaying, volume]); // Re-run the effect if either the URL or the start time changes

  return <audio ref={audioRef} preload="auto" loop hidden />;
}


export default BackgroundMusic;
