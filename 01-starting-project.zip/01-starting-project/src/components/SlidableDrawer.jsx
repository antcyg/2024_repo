import React, { useState } from 'react';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemIcon from '@mui/material/ListItemIcon';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import HomeIcon from '@mui/icons-material/Home';
import ViewListIcon from '@mui/icons-material/ViewList';
import SettingsIcon from '@mui/icons-material/Settings';
import VolumeOffIcon from '@mui/icons-material/VolumeOff'; // For muted state
import VolumeUpIcon from '@mui/icons-material/VolumeUp'; // For unmuted state
import BackgroundMusic from './BackgroundMusic';
import { Box } from '@mui/system';

const chapters = [
  { name: 'Chapter 1: Introduction' },
  { name: 'Chapter 2: Getting Started' },
  { name: 'Chapter 3: Advanced Topics' },
  // Add more chapters as needed
];

const SlidableDrawer = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(true);

  const toggleDrawer = (open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }
    setIsOpen(open);
  };

  const toggleSound = () => {
    setIsMuted(!isMuted);
  };

  const menuItems = [
    { text: 'Home', icon: <HomeIcon />, action: () => console.log('Home Clicked') },
    { text: 'Table of Content', icon: <ViewListIcon />, action: () => console.log('Table of Content Clicked') },
    { text: 'Control Panels', icon: <SettingsIcon />, action: () => console.log('Control Panels Clicked') },
  ]
  return (
    <Box sx={{ position: 'absolute' }}>
      <Box sx={{ position: 'absolute', top: 0, left: 0 }}>
        <IconButton color="inherit" onClick={toggleDrawer(true)}>
          <MenuIcon />
        </IconButton>
      </Box>
      <Drawer
        anchor={'left'}
        open={isOpen}
        onClose={toggleDrawer(false)}
      >
        <List>
          {menuItems.map((item, index) => (
            <Tooltip title={item.text} placement="right" key={index}>
              <ListItem button onClick={item.action}>
                <ListItemIcon>{item.icon}</ListItemIcon>
              </ListItem>
            </Tooltip>
          ))}
        </List>
      </Drawer>
    </Box>
  );
};

export default SlidableDrawer;
