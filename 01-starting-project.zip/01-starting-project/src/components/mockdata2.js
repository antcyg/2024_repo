const mock_data_2 = {
    "ce21b16b-70e5-4020-8766-5ed564a8ce19": {
      "text": [
      {
      "start_time": 0,
      "end_time": 25448,
      "value": "‘Well,’ said Joyce, ‘it seems to me we are a pretty representative gathering. How would it be if we formed a Club? What is today? Tuesday? We will call it The Tuesday Night Club. It is to meet every week, and each member in turn has to propound a problem. Some mystery of which they have personal knowledge, and to which, of course, they know the answer. Let me see, how many are we? One, two, three, four, five. We ought really to be six.’ ",
      },
      {
        "start_time": 25448,
        "end_time": 30240,
        "value": "‘You have forgotten me, dear,’ said Miss Marple, smiling brightly. "
      },
      {
        "start_time": 30240,
        "end_time": 40538,
        "value": "Joyce was slightly taken aback, but she concealed the fact quickly. ‘That would be lovely, Miss Marple,’ she said. ‘I didn’t think you would care to play.’ "
  
      },
      {
        "start_time": 40538,
        "end_time": 55413,
        "value": "‘I think it would be very intersting,’ said Miss Marple, ‘especially with so many clever gentlemen present. I am afraid I am not clever myself, but living all these years in St Mary Mead does give one an insight into human nature.’ "
      },
    ],
    "narration": "https://video-book-narration.s3.amazonaws.com/TheThirteenProblems/Chapter1/1_1_9.mp3",
    "bgm": "https://video-book-narration.s3.amazonaws.com/TheThirteenProblems/Chapter1/february-night-193416.mp3"
    },
    "96c9c9ba-a458-4e38-80a2-f286a6f4f205": {
      "text": [
      {
      "start_time": 0,
      "end_time": 5101,
      "value": "‘I am sure your co-operation will be very valuable,’ said Sir Henry, courteously. "    
      },
      {
        "start_time": 5101,
        "end_time": 8345,
        "value": "‘Who is going to start?’ said Joyce. "
      },
      {
        "start_time": 8345,
        "end_time": 23939,
        "value": "‘I think there is no doubt as to that,’ said Dr Pender, ‘when we have the great good fortune to have such a distinguished man as Sir Henry staying with us –’  He left his sentence unfinished, making a courtly bow in the direction of Sir Henry. "
      },
      {
        "start_time": 23939,
        "end_time": 50469,
        "value": "The latter was silent for a minute or two. At last he sighed and recrossed his legs and began: ‘It is a little difficult for me to select just the kind of thing you want, but I think, as it happens, I know of an instance which fits these conditions very aptly. You may have seen some mention of the case in the papers of a year ago. It was laid aside at the time as an unsolved mystery, but, as it happens, the solution came into my hands not very many days ago. "
      },
    ],
    "narration": "https://video-book-narration.s3.amazonaws.com/TheThirteenProblems/Chapter1/1_1_10.mp3",
    "bgm": "https://video-book-narration.s3.amazonaws.com/TheThirteenProblems/Chapter1/february-night-193416.mp3"
    },
    "bd45e933-89f6-403d-85df-44ba6f0b4681": {
      "text": [
      {
      "start_time": 0,
      "end_time": 15017,
      "value": "‘The facts are very simple. Three people sat down to a supper consisting, amongst other things, of tinned lobster. Later in the night, all three were taken ill, and a doctor was hastily summoned. Two of the people recovered, the third one died.’ "    
      },
      {
        "start_time": 15017,
        "end_time": 18074,
        "value": "‘Ah!’ said Raymond approvingly.  "
      },
      {
        "start_time": 18074,
        "end_time": 30163,
        "value": "‘As I say, the facts as such were very simple. Death was considered to be due to ptomaine poisoning, a certificate was given to that effect, and the victim was duly buried. But things did not rest at that.’ "
      },
      {
        "start_time": 30163,
        "end_time": 37428,
        "value": "Miss Marple nodded her head. ‘There was talk, I suppose,’ she said, ‘there usually is.’ " 
       },
    ],
    "narration": "https://video-book-narration.s3.amazonaws.com/TheThirteenProblems/Chapter1/1_1_11.mp3",
    "bgm": "https://video-book-narration.s3.amazonaws.com/TheThirteenProblems/Chapter1/cold-mind-enigma-crime-mysterious-detective-music-loopable-13553.mp3"
    },
    "3ac113c6-a84b-4c85-9dcc-32a026b96fb5": {
      "text": [
      {
      "start_time": 0,
      "end_time": 16419,
    "value": "‘And now I must describe the actors in this little drama. I will call the husband and wife Mr and Mrs Jones, and the wife’s companion Miss Clark. Mr Jones was a traveller for a firm of manufacturing chemists. He was a good-looking man in a kind of coarse, florid way, aged about fifty. "
      },
      {
        "start_time": 16419,
        "end_time": 30231,
        "value": "His wife was a rather commonplace woman, of about forty-five. The companion, Miss Clark, was a woman of sixty, a stout cheery woman with a beaming rubicund face. None of them, you might say, very interesting. "
      },
      {
        "start_time": 30231,
        "end_time": 38138,
      "value": "‘Now the beginning of the troubles arose in a very curious way. Mr Jones had been staying the previous night at a small commercial hotel in Birmingham. "    },
      {
        "start_time": 38138,
        "end_time": 52073,
      "value": "It happened that the blotting paper in the blotting book had been put in fresh that day, and the chambermaid, having apparently nothing better to do, amused herself by studying the blotter in the mirror just after Mr Jones had been writing a letter there. "     },
    ],
    "narration": "https://video-book-narration.s3.amazonaws.com/TheThirteenProblems/Chapter1/1_1_12.mp3",
    "bgm": "https://video-book-narration.s3.amazonaws.com/TheThirteenProblems/Chapter1/cold-mind-enigma-crime-mysterious-detective-music-loopable-13553.mp3"
    },
  
  };


  export default mock_data_2;