// theme.js
import { createTheme } from '@mui/material/styles';
// '#222f3e', 
// 'radial-gradient(circle, #0D1B2A 0%, #000000 70%)',
const theme = createTheme({
  palette: {
    background: {
      default: '#222f3e',
    },
    text: {
      primary: '#ffffff',
    },
  },
  typography: {
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
    allVariants: {
      color: '#ffffff',
    },
  },
});

export default theme;