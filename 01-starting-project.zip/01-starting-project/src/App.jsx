
import React, {useState, useEffect, useRef} from 'react';
import SlidableDrawer from './components/SlidableDrawer';
import Narration from './components/Narration';
import BackgroundMusic from './components/BackgroundMusic';
import CenteredPaper from './components/CenteredPaper';
import GlobalClickListener from './components/GlobalClickListener';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { Box, Fade } from '@mui/material';
import { ThemeProvider, CssBaseline, Typography } from '@mui/material';
import theme from './components/theme';
import MainBox from './components/MainBox';
import mock_data_1 from './components/mockdata';
import mock_data_2 from './components/mockdata2';





function App() {
  const [currentEpisodeIndex, setCurrentEpisodeIndex] = useState(0);
  const [currentPartIndex, setCurrentPartIndex] = useState(0);
  const prevNarrationBgm = useRef({ narration: null, bgm: null });
  const [iconState, setIconState] = useState({ show: false, direction: '' });
  const [playPauseState, setPlayPauseState] = useState({ show: false, isPlaying: false });
  const [isPlaying, setIsPlaying] = useState(true); 
  const [bgmPlaying, setBgmPlaying] = useState(false);
  const [navIconState, setNavIconState] = useState({ show: false });

  const episodes = mock_data_1; 
  const episodeContent = mock_data_2; 

  const findNavigationPair = (direction) => {
    
    let newEpisodeIndex = currentEpisodeIndex;
    let newPartIndex = currentPartIndex + direction;

    if (direction === 1 && newPartIndex >= episodeContent[episodes[newEpisodeIndex].episode_id].text.length) {
      // Attempt to move to next episode
      newPartIndex = 0;
      newEpisodeIndex += 1;
      if (newEpisodeIndex >= episodes.length) {
        // At the end, do nothing
        return null;
      }
    } else if (direction === -1 && newPartIndex < 0) {
      // Attempt to move to previous episode
      newEpisodeIndex -= 1;
      if (newEpisodeIndex < 0) {
        // At the beginning, do nothing
        return null;
      }
      newPartIndex = episodeContent[episodes[newEpisodeIndex].episode_id].text.length - 1;
    }

    return { newEpisodeIndex, newPartIndex };
  };

  const navigate = (direction) => {
    const navigationPair = findNavigationPair(direction);
    
    if (navigationPair) {
      setCurrentEpisodeIndex(navigationPair.newEpisodeIndex);
      setCurrentPartIndex(navigationPair.newPartIndex);
    }
  };
  
  // Click event handler for navigation
  const handlePageClick = (event) => {
    const { clientX } = event;
    const thirdOfWidth = window.innerWidth / 3;

    if (clientX < thirdOfWidth) {
      navigate(-1); // Left third, navigate back
      setIconState({ show: true, direction: 'left' });
      setTimeout(() => setIconState({ show: false, direction: 'left' }), 1000); // Adjust timing as needed
      setNavIconState({ show: true });
      setTimeout(() => setNavIconState({ show: false }), 5000); // Hide the icon after a delay
    } else if (clientX > thirdOfWidth * 2) {
      navigate(1); // Right third, navigate forward
      setIconState({ show: true, direction: 'right' });
      setTimeout(() => setIconState({ show: false, direction: 'right' }), 1000); // Adjust timing as needed
      setNavIconState({ show: true });
      setTimeout(() => setNavIconState({ show: false }), 5000); // Hide the icon after a delay
    } else {
      // Middle third does nothing in this setup
      setIsPlaying(!isPlaying);
      setPlayPauseState({ show: true, isPlaying: isPlaying });
      setTimeout(() => setPlayPauseState({ show: false, isPlaying: isPlaying }), 1000); // Adjust timing as needed
      if (!bgmPlaying) setBgmPlaying(true);
    }

  };


  // Current episode and part details
  const currentEpisode = episodes[currentEpisodeIndex] || {};
  const currentEpisodeId = currentEpisode.episode_id;
  const currentPart = episodeContent[currentEpisodeId] ? episodeContent[currentEpisodeId].text[currentPartIndex] : null;
  const currentNarration = episodeContent[currentEpisodeId] ? episodeContent[currentEpisodeId].narration : null;
  const currentBgm = episodeContent[currentEpisodeId] ? episodeContent[currentEpisodeId].bgm : null;

  // Determine narration and BGM display values
  const narrationDisplay = currentNarration === prevNarrationBgm.current.narration ? 'same' : currentNarration;
  const bgmDisplay = currentBgm === prevNarrationBgm.current.bgm ? 'same' : currentBgm;

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <SlidableDrawer />
      <MainBox 
      handlePageClick={handlePageClick} 
      currentPart={currentPart} 
      iconState={iconState} 
      playPauseState={playPauseState}
      navIconState={navIconState}
      />
      <Narration 
      url={currentNarration} 
      isPlaying={isPlaying} 
      startTime={currentPart.start_time} 
      endTime={currentPart.end_time}/>
      <BackgroundMusic url={currentBgm} isPlaying={bgmPlaying} volume={0.15}/>
    </ThemeProvider>
  );

}

export default App;
